# Escopo e premissas

## Escopo
- User Story 2: visualizar o custo total da frota de forma consolidada.

## Fora do escopo principal desta etapa
- OCR de imagens e PDFs;
- comparação com benchmark externo;
- identificação automática de ineficiências;
- estimativa de economia;
- recomendações automáticas;
- sistema de autenticação funcional ou banco de dados implementado.

## Premissas
- O dataset é fictício e serve apenas para demonstração.
- Os custos devem pertencer a um mesmo período antes de serem somados.
- Campos ausentes precisam ser sinalizados.
- O total consolidado não deve ser apresentado como diagnóstico de eficiência nem como promessa de economia.
