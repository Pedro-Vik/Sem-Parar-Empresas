# Calculadora de Redução de Custos de Frota — Sem Parar Empresas

## 1. Resumo do projeto
Este projeto apresenta a proposta inicial de uma calculadora para consolidar os custos de uma frota e facilitar a visualização do gasto total mensal pelo gestor.

**Escopo principal da Sprint 1:** User Story 2 — visualização do custo total da frota de forma consolidada.

Nesta etapa, o objetivo é documentar a solução, os dados e a arquitetura proposta. **Não é necessário entregar software funcional ou protótipo nesta Sprint 1**, conforme as orientações do desafio.

## 2. Problema de negócio
Os custos de uma frota podem estar espalhados por diferentes fontes e formatos, dificultando a visão consolidada de combustível, manutenção, pedágios, multas, impostos e outras despesas. Sem uma visão única, o gestor tem mais dificuldade para entender quanto a operação custa no mês.

## 3. User Story selecionada
> Como gestor de frota, quero visualizar o custo total da minha frota de forma consolidada, para entender quanto realmente estou gastando com a operação.

### Como a proposta atende à User Story
A solução receberá dados de veículos e categorias de despesas, padronizará os valores e somará os custos por veículo e por frota. O resultado será apresentado em uma visão mensal com:
- custo total da frota;
- custo por veículo;
- composição por categoria de despesa;
- período de referência e avisos sobre dados ausentes.

**Limite de escopo:** a US2 é a história priorizada nesta proposta. Diagnóstico avançado, benchmarks e recomendações podem ser evoluções posteriores; são descritos como possibilidades, não como funcionalidades já implementadas.

## 4. Dados utilizados
Foi preparado um conjunto de dados **simulados/fictícios** para demonstrar a estrutura de informações. Os valores não representam clientes reais nem dados oficiais da Sem Parar.

- Arquivo: [`dados/dataset_frota_simulado.csv`](dados/dataset_frota_simulado.csv)
- Dicionário: [`dados/dicionario_dados.xlsx`](dados/dicionario_dados.xlsx)
- Quantidade de veículos no exemplo: **20**
- Soma dos custos mensais simulados: **R$ 193.164,91**
- Custo mensal médio simulado por veículo: **R$ 9.658,25**

## 5. Estrutura das informações
As principais categorias consideradas são:
- combustível;
- manutenção;
- pedágios;
- multas;
- impostos;
- outros custos;
- custo total mensal por veículo.

O CSV contém variáveis adicionais, como identificação fictícia do veículo, modelo, ano, quilometragem mensal e indicadores de consumo. O dicionário de dados explica as colunas disponíveis.

## 6. Entrada e tratamento de dados — proposta
Para uma evolução futura, a solução poderá aceitar planilhas CSV/XLSX e, em etapas posteriores, PDFs, imagens e capturas de tela. Para a primeira versão conceitual:
1. importar arquivo tabular;
2. conferir colunas e tipos de dados;
3. normalizar datas, números e moeda;
4. validar campos ausentes, valores negativos e duplicidades;
5. calcular o total por veículo e por categoria;
6. apresentar o total consolidado e indicar limitações dos dados.

## 7. Regra de cálculo proposta
Para cada veículo:

**Custo mensal do veículo = combustível + manutenção + pedágios + multas + impostos + outros custos.**

Para a frota:

**Custo mensal total da frota = soma dos custos mensais de todos os veículos válidos no período.**

O sistema deverá evitar somar valores de períodos diferentes e sinalizar registros incompletos. Caso algum componente esteja ausente, deverá indicar que o total pode estar subestimado, em vez de assumir silenciosamente que o custo é zero.

## 8. Exemplo de resultado
Com os dados simulados fornecidos:
- veículos no exemplo: **20**;
- custo mensal total da frota: **R$ 193.164,91**;
- custo mensal médio por veículo: **R$ 9.658,25**.

Esses números servem apenas para demonstrar a consolidação. Não são uma promessa de economia, benchmark de mercado ou resultado de uma operação real.

## 9. Diagnóstico, recomendações e evolução
Como a US2 é o foco, o resultado principal será a consolidação dos custos. Como evolução futura, o projeto poderá:
- identificar categorias com maior participação no custo;
- comparar períodos, se houver dados comparáveis;
- incorporar benchmarks confiáveis, quando disponíveis;
- estimar oportunidades de economia somente com premissas explícitas;
- recomendar ações e indicar o próximo passo ao gestor.

Não serão inventados benchmarks externos. Qualquer referência futura deverá ter fonte, período, contexto e critérios de comparação documentados.

## 10. Dados incompletos e qualidade
A proposta prevê:
- destacar campos obrigatórios ausentes;
- informar quais despesas não foram incluídas;
- não tratar dado desconhecido automaticamente como zero;
- registrar a origem e o período dos dados;
- sinalizar duplicidades e valores fora do padrão;
- apresentar um aviso quando o total for parcial.

## 11. Segurança e privacidade
Os dados de exemplo são fictícios. Em uma versão real, seriam necessários controle de acesso, autenticação, armazenamento protegido, registro de alterações e coleta mínima de dados pessoais. Os dados de identificação e contato do cliente só seriam usados para finalidades justificadas e comunicadas, seguindo as políticas aplicáveis de privacidade e proteção de dados.

## 12. Arquitetura inicial
O fluxo conceitual está em [`arquitetura/diagrama-arquitetura.png`](arquitetura/diagrama-arquitetura.png) e é descrito em [`docs/arquitetura.md`](docs/arquitetura.md).

Fluxo principal: entrada de dados → validação/padronização → cálculo dos custos → consolidação → visualização/relatório.

## 13. Planejamento das próximas etapas
1. **Sprint 1 — planejamento:** definir escopo, User Story, dados, regras de cálculo, arquitetura e riscos.
2. **Sprint seguinte — validação dos dados:** revisar o dataset, validar fórmulas e definir casos de teste.
3. **Sprint seguinte — protótipo:** criar uma interface simples para carregar dados e visualizar totais.
4. **Sprint seguinte — testes:** testar dados incompletos, duplicados e inconsistentes.
5. **Evolução futura:** avaliar diagnóstico, benchmarks e recomendações conforme tempo e requisitos.

As responsabilidades dos integrantes devem ser preenchidas pelo grupo em [`docs/planejamento.md`](docs/planejamento.md).

## 14. Apresentação em vídeo
O roteiro sugerido está em [`apresentacao/roteiro-video.md`](apresentacao/roteiro-video.md). O vídeo final deve ter até 5 minutos, ser publicado como **não listado** e ter o link inserido aqui e no arquivo `.txt` de submissão.

**Link do vídeo:** `[INSERIR LINK DO YOUTUBE]`

## 15. Organização do repositório
- `dados/`: dataset simulado e dicionário de dados;
- `docs/`: arquitetura, análise, planejamento e notas de escopo;
- `arquitetura/`: diagrama visual;
- `README.md`: documento principal da proposta.