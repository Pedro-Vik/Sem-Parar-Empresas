# Arquitetura proposta

## Fluxo da US2
1. **Entrada:** o gestor envia uma planilha CSV/XLSX.
2. **Validação:** o sistema verifica colunas, formatos, período, campos ausentes e duplicidades.
3. **Padronização:** normaliza números, moeda e nomes de categorias.
4. **Cálculo:** soma as despesas de cada veículo.
5. **Consolidação:** soma os veículos válidos para produzir o custo total da frota.
6. **Visualização/relatório:** mostra total geral, total por veículo, categorias e avisos de qualidade.

## Componentes conceituais
- Interface de importação e resultados.
- Módulo de validação e padronização.
- Módulo de cálculo/regras de negócio.
- Camada de armazenamento protegida (necessária em uma versão real).
- Gerador de relatório.

## Decisão de escopo
Para reduzir complexidade, a primeira versão conceitual prioriza CSV/XLSX. OCR para imagens e PDFs, benchmarks, inteligência artificial e recomendações são possíveis extensões, mas não são necessárias para demonstrar a consolidação da US2.

## Segurança
Uma versão real deve usar autenticação, controle de acesso por perfil, proteção em trânsito e armazenamento, logs de alterações e regras de retenção/exclusão de dados.
