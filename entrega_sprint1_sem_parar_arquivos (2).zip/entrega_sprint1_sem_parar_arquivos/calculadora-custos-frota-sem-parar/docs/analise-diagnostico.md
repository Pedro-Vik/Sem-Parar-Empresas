# Análise demonstrativa dos custos

## Objetivo
Demonstrar a consolidação exigida pela User Story 2 (US2). Este documento utiliza dados fictícios e não representa uma auditoria de frota real.

## Resultado agregado
- Quantidade de veículos: 20
- Custo mensal total simulado: R$ 193.164,91
- Custo mensal médio por veículo: R$ 9.658,25

## Como interpretar
O custo total é a soma dos custos mensais registrados para os veículos incluídos no dataset. A média por veículo é o custo total dividido pela quantidade de registros de veículos.

## Limitações
- Os dados são simulados.
- Não há garantia de que todos os custos de uma operação real estejam representados.
- Não foram aplicados benchmarks externos.
- O total consolidado não prova, sozinho, que existe ineficiência ou economia potencial.
- Antes de comparar veículos, seria necessário considerar quilometragem, tipo de veículo, carga, rota, combustível e período.

## Próximas validações
1. Conferir se todos os registros pertencem ao mesmo mês.
2. Verificar se a soma das categorias corresponde ao campo de custo total.
3. Identificar campos vazios e duplicidades.
4. Comparar os resultados com uma fonte de controle independente.
